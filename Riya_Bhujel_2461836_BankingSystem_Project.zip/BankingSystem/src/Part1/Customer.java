package Part1;

public class Customer {
    
    private String firstName;
    private String lastName;

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setFirstName(String FName) {
        this.firstName = FName;
    }

    public void setLastName(String LName) {
        this.lastName = LName;
    }
}